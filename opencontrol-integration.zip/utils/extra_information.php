<?php
class ExtraInformation
{
    public $number;
    public $holder;
    public $session;
}