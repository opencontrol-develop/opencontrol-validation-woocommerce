<?php

class Merchant 
{
    const REQUIRED_FIELDS = [
        'id'
    ];
    
    public $id;
}